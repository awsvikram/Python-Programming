
## Development

### Create Repos

```
aws ecr create-repository \
    --repository-name lambda-link/controller \
    --image-scanning-configuration scanOnPush=true \
    --region "${AWS_DEFAULT_REGION}"
aws ecr create-repository \
    --repository-name lambda-link/multi-compute \
    --image-scanning-configuration scanOnPush=true \
    --region "${AWS_DEFAULT_REGION}"

export KO_DOCKER_REPO="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_DEFAULT_REGION}.amazonaws.com/lambda-link"
```

## Installation

1. Create the IAM Policies
```bash
./scripts/01-create-iam-policy.sh
````

2. Create the lambda-link service account
```bash
./scripts/02-create-service-account.sh
```


## On the Node for the first time
```
echo 2 > /proc/sys/net/ipv4/conf/default/rp_filter
echo 2 > /proc/sys/net/ipv4/conf/all/rp_filter
```

## update your aws-auth CM
```
    - groups:
      - system:bootstrappers
      - system:nodes
      rolearn: arn:aws:iam::399082912554:role/tnealt-karpenter-demo-lambda-link
      username: system:node:fargate-192.168.49.112
```

## update kube-proxy

```
kubectl edit cm kube-proxy-config -n kube-system

data:
  config:
    clusterCIDR: "192.168.0.0/16"

## delete the kube-proxy pod on the lambda-link node to restart it
```


## Demo

Install load balance controller per https://docs.aws.amazon.com/eks/latest/userguide/aws-load-balancer-controller.html

Tag your cluster shared node security group with `kubernetes.io/cluster/${CLUSTER_NAME}: owned`

vpc.amazonaws.com/pod-eni

[{"eniId":"eni-00215046443ab68cc","ifAddress":"0a:9b:36:0d:90:87","privateIp":"172.16.0.1","vlanId":1,"subnetCidr":"172.16.0.0/24"}]