package kubelet_test

import (
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"testing"
)

func TestFoo(t *testing.T) {
	pemBytes, _ := base64.StdEncoding.DecodeString(`LS0tLS1CRUdJTiBDRVJUSUZJQ0FURSBSRVFVRVNULS0tLS0KTUlJQkdqQ0J3QUlCQURBME1SVXdFd1lEVlFRS0V3eHplWE4wWlcwNmJtOWtaWE14R3pBWkJnTlZCQU1URW5ONQpjM1JsYlRwdWIyUmxPbXhoYldKa1lUQlpNQk1HQnlxR1NNNDlBZ0VHQ0NxR1NNNDlBd0VIQTBJQUJFRUV5aDdQClJkSnNUeG5hUnhtdldTb08zNC9aTXlWYVl3SnRWMXlOd3hPaXliZUxrdGVRNlVQZXRrRXdJL2RiOFdwTGFEMFgKRSt4WFh2eU5IanQ2UE1PZ0tqQW9CZ2txaGtpRzl3MEJDUTR4R3pBWk1CY0dBMVVkRVFRUU1BNkNCbXhoYldKawpZWWNFckJBQUFUQUtCZ2dxaGtqT1BRUURBZ05KQURCR0FpRUE2aXNWQVp2elFpV2pINmhZYURkOGdpME4rekNBCnp2OXJLOGhlbytWK2luc0NJUURRVEo2MWJDUTdscDF6YktoNjBSL1E0dUJNOUpJVERHWDdwK2xzYjdaQ3N3PT0KLS0tLS1FTkQgQ0VSVElGSUNBVEUgUkVRVUVTVC0tLS0tCg==`)
	block, err := pem.Decode(pemBytes)
	fmt.Println(block, err)
	csr, err2 := x509.ParseCertificateRequest(block.Bytes)
	if err2 != nil {
		t.Fatal(err)
	}
	signerName := "kubernetes.io/kubelet-serving"
	usages := []string{"digital signature", "key encipherment", "server auth"}
	x509cr := csr
	_ = x509cr
	_ = signerName
	_ = usages
}
