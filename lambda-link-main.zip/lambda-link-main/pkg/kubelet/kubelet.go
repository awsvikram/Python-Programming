package kubelet

import (
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/awslabs/lambda-link/pkg/network"
	"github.com/awslabs/lambda-link/pkg/p2l"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/util/certificate"
	"k8s.io/klog/v2"
	"k8s.io/kubernetes/pkg/kubelet/apis/config"
	kubeletcertificate "k8s.io/kubernetes/pkg/kubelet/certificate"
	"net/http"
	"os"
	"strings"
	"time"
)

const certsDir = "/var/kubelet/certs"

type Kubelet struct {
	nw      *network.Network
	certMgr certificate.Manager
	proxy   *p2l.Proxy
}

func NewKubelet(nw *network.Network, client *kubernetes.Clientset, sess *session.Session, proxy *p2l.Proxy) (*Kubelet, error) {
	k := &Kubelet{
		nw:    nw,
		proxy: proxy,
	}

	caContent, err := base64.StdEncoding.DecodeString(os.Getenv("CLUSTER_CA"))
	if err != nil {
		return nil, fmt.Errorf("CLUSTER_CA unspcified or invalidly formatted")
	}
	clusterName := os.Getenv("CLUSTER_NAME")
	if clusterName == "" {
		return nil, fmt.Errorf("CLUSTER_NAME unspecified")
	}
	clusterEndpoint := os.Getenv("CLUSTER_ENDPOINT")
	if clusterEndpoint == "" {
		return nil, fmt.Errorf("clusterEndpoint unspecified")
	}
	awsRegion := os.Getenv("AWS_REGION")
	if awsRegion == "" {
		return nil, fmt.Errorf("awsRegion unspecified")
	}

	klog.Infof("creating lambda node for %s at %s", clusterName, clusterEndpoint)
	caFile, err := os.CreateTemp("", "ca*")
	if err != nil {
		return nil, fmt.Errorf("creating temp file for CA, %w", err)
	}
	caFileName := caFile.Name()
	caFile.Write(caContent)
	caFile.Close()

	kubeConfigContent := boostrapKubeConfig
	kubeConfigContent = strings.Replace(kubeConfigContent, "CA_FILE", caFileName, -1)
	kubeConfigContent = strings.Replace(kubeConfigContent, "MASTER_ENDPOINT", clusterEndpoint, -1)
	kubeConfigContent = strings.Replace(kubeConfigContent, "CLUSTER_NAME", clusterName, -1)
	kubeConfigContent = strings.Replace(kubeConfigContent, "AWS_REGION", awsRegion, -1)

	bootstrapFile, err := os.CreateTemp("", "bootstrap*")
	if err != nil {
		return nil, fmt.Errorf("creating temp file for boostrap, %w", err)
	}
	bootstrapFileName := bootstrapFile.Name()
	bootstrapFile.WriteString(kubeConfigContent)
	bootstrapFile.Close()

	kubeCfg := &config.KubeletConfiguration{}
	restCfg, err := clientcmd.BuildConfigFromFlags("", bootstrapFileName)
	if err != nil {
		klog.Errorf("creating kubeconfig from bootstrap, %s", err)
	}

	nodeName := types.NodeName(fmt.Sprintf("fargate-%s", nw.NodeIP))
	mgr, err := kubeletcertificate.NewKubeletServerCertificateManager(kubernetes.NewForConfigOrDie(restCfg), kubeCfg, nodeName, k.getNodeAddress, certsDir)
	if err != nil {
		return nil, fmt.Errorf("creating server cert manager, %w", err)
	}
	k.certMgr = mgr
	mgr.Start()

	addr := fmt.Sprintf("%s:10250", nw.NodeIP)
	klog.Infof("kubelet listening on %s", addr)

	mux := http.NewServeMux()
	mux.HandleFunc("/metrics/", k.serveMetrics)
	mux.HandleFunc("/containerLogs/", k.serveLogs)
	server := &http.Server{
		Addr:        addr,
		Handler:     mux,
		IdleTimeout: 5 * time.Second,
		TLSConfig: &tls.Config{
			GetCertificate: func(*tls.ClientHelloInfo) (*tls.Certificate, error) {
				cert := mgr.Current()
				if cert == nil {
					return nil, fmt.Errorf("no serving certificate available for the kubelet")
				}
				return cert, nil
			},
		},
	}

	go func() {
		if err := server.ListenAndServeTLS("", ""); err != nil {
			klog.Fatalf("listen and serve kubelet, %s", err)
		}
	}()

	return k, nil
}

func (k Kubelet) serveMetrics(w http.ResponseWriter, request *http.Request) {

}

func (k Kubelet) getNodeAddress() []v1.NodeAddress {
	return []v1.NodeAddress{
		{
			Type:    v1.NodeInternalIP,
			Address: k.nw.NodeIP.String(),
		},
	}
}

func (k Kubelet) serveLogs(w http.ResponseWriter, request *http.Request) {
	follow := request.URL.Query().Get("follow") == "true"
	segs := strings.Split(request.URL.Path, "/")
	w.Header().Set("Transfer-Encoding", "chunked")

	if len(segs) != 5 {
		klog.Errorf("expected 5 segments, got %q", segs)
		return
	}
	namespace := segs[2]
	podName := segs[3]
	containerName := segs[4]
	k.proxy.ServeLogs(w, namespace, podName, containerName, follow)
}
