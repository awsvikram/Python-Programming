package project

const Version = "0.0.1"
