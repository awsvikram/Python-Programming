package network

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net"
	"strings"
	"syscall"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/ec2metadata"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
	"github.com/vishvananda/netlink"
	"k8s.io/klog/v2"
)

type Network struct {
	NodeIP    net.IP
	ec2api    *ec2.EC2
	nodeENI   *ec2.NetworkInterface
	nodeLink  netlink.Link
	lambdaIPs []net.IP
}

func New(ctx context.Context, sess *session.Session) (*Network, error) {
	ec2api := ec2.New(sess)
	doc, err := ec2metadata.New(sess).GetInstanceIdentityDocument()
	if err != nil {
		return nil, fmt.Errorf("failed to call the metadata server's GetInstanceIdentityDocument API, %w", err)
	}
	info, err := ec2api.DescribeInstancesWithContext(ctx, &ec2.DescribeInstancesInput{
		Filters:     nil,
		InstanceIds: []*string{aws.String(doc.InstanceID)},
	})
	if err != nil {
		return nil, fmt.Errorf("failed to call the ec2:DescribeInstances API, %w", err)
	}

	instanceInfo := *info.Reservations[0].Instances[0]

	nw := &Network{
		ec2api: ec2api,
	}

	primaryNetworkInterfaceID := ""
	for _, nic := range instanceInfo.NetworkInterfaces {
		if *nic.Attachment.DeviceIndex == 0 {
			primaryNetworkInterfaceID = *nic.NetworkInterfaceId
		}
	}

	// Add cluster-ip virtual routes in the VPC:
	vpcs, err := nw.ec2api.DescribeVpcsWithContext(ctx, &ec2.DescribeVpcsInput{VpcIds: []*string{instanceInfo.VpcId}})
	if err != nil {
		return nil, fmt.Errorf("failed to describe vpc to check if VPC CIDR overlaps cluster-ips, %w", err)
	}
	if len(vpcs.Vpcs) > 0 {
		if strings.HasPrefix(*vpcs.Vpcs[0].CidrBlock, "10.0.0.0") {
			klog.Infof("Skipping cluster-ip VPC routes because VPC CIDR (%s) overlaps with cluster-ips", *vpcs.Vpcs[0].CidrBlock)
		} else {
			if err := nw.ec2api.DescribeRouteTablesPagesWithContext(ctx, &ec2.DescribeRouteTablesInput{
				Filters: []*ec2.Filter{
					{
						Name:   aws.String("vpc-id"),
						Values: []*string{instanceInfo.VpcId},
					},
				},
			}, func(drto *ec2.DescribeRouteTablesOutput, _ bool) bool {
				for _, rt := range drto.RouteTables {
					klog.Infof("Adding cluster-ip route to %s", *rt.RouteTableId)
					if _, err := nw.ec2api.CreateRouteWithContext(ctx, &ec2.CreateRouteInput{
						RouteTableId:         rt.RouteTableId,
						DestinationCidrBlock: aws.String("10.0.0.0/8"),
						NetworkInterfaceId:   &primaryNetworkInterfaceID,
					}); err != nil {
						klog.Errorf("failed to update route table %s with cluster-ip route, %v", *rt.RouteTableId, err)
					}
				}
				return true
			}); err != nil {
				return nil, fmt.Errorf("failed to describe route tables to add cluster-ips, %w", err)
			}
		}
	}

	// Remove Source/Dest IP check on primary interface
	if _, err := ec2api.ModifyNetworkInterfaceAttributeWithContext(ctx, &ec2.ModifyNetworkInterfaceAttributeInput{
		NetworkInterfaceId: &primaryNetworkInterfaceID,
		SourceDestCheck:    &ec2.AttributeBooleanValue{Value: aws.Bool(false)},
	}); err != nil {
		return nil, fmt.Errorf("failed to disable source/dest IP check on the primary network interface, %w", err)
	}

	// Find the lambda node ENI
	const lambdaLinkENITag = "lambda-link-node"
	maxDeviceIndex := int64(0)
	for _, nic := range instanceInfo.NetworkInterfaces {
		if aws.StringValue(nic.Description) == lambdaLinkENITag {
			nw.NodeIP = net.ParseIP(aws.StringValue(nic.PrivateIpAddress))
			nics, err := ec2api.DescribeNetworkInterfaces(&ec2.DescribeNetworkInterfacesInput{
				NetworkInterfaceIds: []*string{nic.NetworkInterfaceId},
			})
			if err != nil {
				return nil, fmt.Errorf("describing Node ENI, %w", err)
			}
			nw.nodeENI = nics.NetworkInterfaces[0]
		}
		if *nic.Attachment.DeviceIndex > maxDeviceIndex {
			maxDeviceIndex = *nic.Attachment.DeviceIndex
		}
	}

	// not found, so make and attach new one
	if nw.NodeIP == nil {
		// copy security groups off the primary ENI
		var securityGroupIDs []*string
		for _, g := range instanceInfo.NetworkInterfaces[0].Groups {
			securityGroupIDs = append(securityGroupIDs, g.GroupId)
		}

		nic, err := ec2api.CreateNetworkInterface(&ec2.CreateNetworkInterfaceInput{
			Description:                    aws.String(lambdaLinkENITag),
			Groups:                         securityGroupIDs,
			SubnetId:                       instanceInfo.NetworkInterfaces[0].SubnetId,
			SecondaryPrivateIpAddressCount: aws.Int64(10),
			TagSpecifications: []*ec2.TagSpecification{
				{
					ResourceType: aws.String("network-interface"),
					Tags: []*ec2.Tag{
						{
							Key:   aws.String(lambdaLinkENITag),
							Value: aws.String("owned"),
						},
						// tell the VPC CNI to leave this interface alone
						{
							Key:   aws.String("node.k8s.amazonaws.com/no_manage"),
							Value: aws.String("true"),
						},
					},
				},
			},
		})
		if err != nil {
			return nil, fmt.Errorf("creating node network interface, %w", err)
		}
		nw.nodeENI = nic.NetworkInterface

		_, err = ec2api.AttachNetworkInterface(&ec2.AttachNetworkInterfaceInput{
			DeviceIndex:        aws.Int64(maxDeviceIndex + 1),
			InstanceId:         instanceInfo.InstanceId,
			NetworkInterfaceId: nic.NetworkInterface.NetworkInterfaceId,
		})
		if err != nil {
			return nil, fmt.Errorf("attaching node network interface, %w", err)
		}
		nw.NodeIP = net.ParseIP(aws.StringValue(nic.NetworkInterface.PrivateIpAddress))
	}

	if nw.NodeIP == nil {
		return nil, fmt.Errorf("no primary or node IP found")
	}

	// determine the netlink link that corresponds to the Node ENI
	links, err := netlink.LinkList()
	if err != nil {
		return nil, fmt.Errorf("enumerating network interfaces, %w", err)
	}
	primaryMac, err := net.ParseMAC(aws.StringValue(nw.nodeENI.MacAddress))
	if err != nil {
		return nil, fmt.Errorf("error parsing MAC %s, %s", aws.StringValue(nw.nodeENI.MacAddress), err)
	}
	for _, link := range links {
		if bytes.Equal(link.Attrs().HardwareAddr, primaryMac) {
			klog.Infof("Primary Link is %s %s/%s", link.Type(), link.Attrs().Name, link.Attrs().HardwareAddr)
			nw.nodeLink = link
		}
	}

	// remove all the lambda IP registrations, so we can re-create them as needed
	addrs, err := netlink.AddrList(nw.nodeLink, FAMILY_V4)
	for _, addr := range addrs {
		// don't remove the node IP
		if addr.IP.Equal(nw.NodeIP) {
			continue
		}
		// but remove any previously registered lambda-pod IPs
		if err := nw.RemoveLambdaIP(addr.IP); err != nil {
			klog.Errorf("removing exising IP %s, %s", addr.IP, err)
		}
	}

	for _, ips := range nw.nodeENI.PrivateIpAddresses {
		ip := net.ParseIP(aws.StringValue(ips.PrivateIpAddress))
		if ip == nil || ip.Equal(nw.NodeIP) {
			continue
		}
		klog.Infof("discovered potential lambda IP %s", ip)
		nw.lambdaIPs = append(nw.lambdaIPs, ip)
	}

	// Ensure that our node IP is attached to the NIC at the OS. This also brings up the
	// interface if it's not running.
	if err := nw.attachPrimaryIP(nw.NodeIP, aws.StringValue(nw.nodeENI.MacAddress)); err != nil {
		return nil, fmt.Errorf("attaching node IP to node ENI, %w", err)
	}
	klog.Infof("discovered  Node IP %s", nw.NodeIP)

	// TODO: need to update the AWS auth config map and add something with the "fargate-node.ip"
	///     - groups:
	//      - system:bootstrappers
	//      - system:nodes
	//      rolearn: arn:aws:iam::399082912554:role/tnealt-karpenter-demo-lambda-link
	//      username: system:node:fargate-192.168.53.97
	return nw, nil
}

func (n *Network) LambdaIPs() []net.IP {
	return n.lambdaIPs
}

// attachPrimaryIP attaches the IP to the interface with the specified MAC adddress
func (n *Network) attachPrimaryIP(ip net.IP, macAddress string) error {
	ip, nip, err := net.ParseCIDR(ip.String() + "/32")
	if err != nil {
		return fmt.Errorf("parsing IP, %w", err)
	}

	links, err := netlink.LinkList()
	if err != nil {
		return fmt.Errorf("enumerating network interfaces, %w", err)
	}
	parsedMac, err := net.ParseMAC(macAddress)
	if err != nil {
		return fmt.Errorf("error parsing MAC %s, %s", macAddress, err)
	}
	for _, link := range links {
		if bytes.Equal(link.Attrs().HardwareAddr, parsedMac) {
			netlink.LinkSetMTU(link, 9001)
			if err := netlink.LinkSetUp(link); err != nil {
				klog.Errorf("setting up link %s, %s", link.Attrs().Name, err)
			}
			err := netlink.AddrAdd(link, &netlink.Addr{
				IPNet: &net.IPNet{
					IP:   ip,
					Mask: nip.Mask,
				}})
			// don't report an error if the IP is already on the interface
			if errors.Is(err, syscall.EEXIST) {
				return nil
			}
			return err
		}
	}
	return fmt.Errorf("unable to find interface with mac address %s", macAddress)
}
