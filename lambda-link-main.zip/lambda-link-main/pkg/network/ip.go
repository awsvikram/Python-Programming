package network

import (
	"errors"
	"fmt"
	"github.com/vishvananda/netlink"
	"net"
	"syscall"
)

func (n *Network) AddLambdaIP(ip net.IP) error {
	ip, nip, err := net.ParseCIDR(ip.String() + "/32")
	if err != nil {
		return fmt.Errorf("parsing IP, %w", err)
	}
	err = netlink.AddrAdd(n.nodeLink, &netlink.Addr{
		IPNet: &net.IPNet{
			IP:   ip,
			Mask: nip.Mask,
		},
	})
	// IP is already registered on the device
	if errors.Is(err, syscall.EEXIST) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("addr-add of %s/%s to %s, %w", ip, nip.Mask, n.nodeLink.Attrs().Name, err)
	}
	return nil
}

func (n *Network) RemoveLambdaIP(ip net.IP) error {
	ip, nip, err := net.ParseCIDR(ip.String() + "/32")
	if err != nil {
		return fmt.Errorf("parsing IP, %w", err)
	}
	err = netlink.AddrDel(n.nodeLink, &netlink.Addr{
		IPNet: &net.IPNet{
			IP:   ip,
			Mask: nip.Mask,
		},
	})
	if err != nil {
		return fmt.Errorf("addr-del on %s with %v/%v, %w", n.nodeLink.Attrs().Name, ip, nip.Mask, err)
	}
	return nil
}
