package network

// FAMILY_V4 has no definition in the netlink package for Darwin, so we define something just to continue
// building
const FAMILY_V4 = 0
