package network

import "github.com/vishvananda/netlink"

const FAMILY_V4 = netlink.FAMILY_V4
