package lambda

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	rlambda "github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-lambda-go/lambda/handlertrace"
	"github.com/awslabs/lambda-link/pkg/p2l"
	"k8s.io/klog/v2"
	"net/http"
	"os"
	"reflect"
)

func StartɁ(handler interface{}) {
	defer klog.Errorf("StartɁ exiting")
	if os.Getenv("AWS_LAMBDA_RUNTIME_API") != "" {
		klog.Info("starting in lambda moda")
		rlambda.Start(handler)
	} else {
		klog.Info("starting in container mode")
		startWebserver(handler)
	}
}

// func ()
// func () error
// func (TIn) error
// func () (TOut, error)
// func (TIn) (TOut, error)
// func (context.Context) error
// func (context.Context, TIn) error
// func (context.Context) (TOut, error)
// func (context.Context, TIn) (TOut, error)
func startWebserver(fn interface{}) {
	if err := http.ListenAndServe(":8888", &handler{h: reflectHandler(fn)}); err != nil {
		klog.Errorf("failed to ListenAndServe, %s", err)
	}
}

// borrowed from the go-lambda client
func reflectHandler(handlerFunc interface{}) Handler {
	if handlerFunc == nil {
		return errorHandler(errors.New("handler is nil"))
	}
	if handler, ok := handlerFunc.(Handler); ok {
		return handler
	}

	handler := reflect.ValueOf(handlerFunc)
	handlerType := reflect.TypeOf(handlerFunc)
	if handlerType.Kind() != reflect.Func {
		return errorHandler(fmt.Errorf("handler kind %s is not %s", handlerType.Kind(), reflect.Func))
	}

	takesContext, err := validateArguments(handlerType)
	if err != nil {
		return errorHandler(err)
	}

	if err := validateReturns(handlerType); err != nil {
		return errorHandler(err)
	}

	return bytesHandlerFunc(func(ctx context.Context, payload []byte) ([]byte, error) {
		in := bytes.NewBuffer(payload)
		out := bytes.NewBuffer(nil)
		decoder := json.NewDecoder(in)
		encoder := json.NewEncoder(out)
		// TODO: use options?
		//encoder.SetEscapeHTML(h.jsonResponseEscapeHTML)
		//encoder.SetIndent(h.jsonResponseIndentPrefix, h.jsonResponseIndentValue)

		trace := handlertrace.FromContext(ctx)

		// construct arguments
		var args []reflect.Value
		if takesContext {
			args = append(args, reflect.ValueOf(ctx))
		}
		if (handlerType.NumIn() == 1 && !takesContext) || handlerType.NumIn() == 2 {
			eventType := handlerType.In(handlerType.NumIn() - 1)
			event := reflect.New(eventType)
			if err := decoder.Decode(event.Interface()); err != nil {
				return nil, err
			}
			if nil != trace.RequestEvent {
				trace.RequestEvent(ctx, event.Elem().Interface())
			}
			args = append(args, event.Elem())
		}

		response := handler.Call(args)

		// return the error, if any
		if len(response) > 0 {
			if errVal, ok := response[len(response)-1].Interface().(error); ok && errVal != nil {
				return nil, errVal
			}
		}
		// set the response value, if any
		var val interface{}
		if len(response) > 1 {
			val = response[0].Interface()
			if nil != trace.ResponseEvent {
				trace.ResponseEvent(ctx, val)
			}
		}
		if err := encoder.Encode(val); err != nil {
			return nil, err
		}

		responseBytes := out.Bytes()
		// back-compat, strip the encoder's trailing newline unless WithSetIndent was used
		// TODO: use options?
		/*if h.jsonResponseIndentValue == "" && h.jsonResponseIndentPrefix == "" {
			return responseBytes[:len(responseBytes)-1], nil
		}*/

		return responseBytes, nil
	})
}

type handler struct {
	h Handler
}

func (h handler) ServeHTTP(w http.ResponseWriter, request *http.Request) {
	if !p2l.RequiresInvoke(request) {
		return
	}

	apiReq, err := p2l.HttpToAPIGatewayRaw(request)
	if err != nil {
		klog.Errorf("constructing request, %s", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	rsp, err := h.h.Invoke(context.Background(), apiReq)
	if err != nil {
		klog.Errorf("invoking lambda, %s", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	p2l.DeliverResponse(rsp, w)
}

type Handler interface {
	Invoke(ctx context.Context, payload []byte) ([]byte, error)
}

type bytesHandlerFunc func(context.Context, []byte) ([]byte, error)

func (h bytesHandlerFunc) Invoke(ctx context.Context, payload []byte) ([]byte, error) {
	return h(ctx, payload)
}
func errorHandler(err error) Handler {
	return bytesHandlerFunc(func(_ context.Context, _ []byte) ([]byte, error) {
		return nil, err
	})
}

func validateArguments(handler reflect.Type) (bool, error) {
	handlerTakesContext := false
	if handler.NumIn() > 2 {
		return false, fmt.Errorf("handlers may not take more than two arguments, but handler takes %d", handler.NumIn())
	} else if handler.NumIn() > 0 {
		contextType := reflect.TypeOf((*context.Context)(nil)).Elem()
		argumentType := handler.In(0)
		handlerTakesContext = argumentType.Implements(contextType)
		if handler.NumIn() > 1 && !handlerTakesContext {
			return false, fmt.Errorf("handler takes two arguments, but the first is not Context. got %s", argumentType.Kind())
		}
	}

	return handlerTakesContext, nil
}

func validateReturns(handler reflect.Type) error {
	errorType := reflect.TypeOf((*error)(nil)).Elem()

	switch n := handler.NumOut(); {
	case n > 2:
		return fmt.Errorf("handler may not return more than two values")
	case n > 1:
		if !handler.Out(1).Implements(errorType) {
			return fmt.Errorf("handler returns two values, but the second does not implement error")
		}
	case n == 1:
		if !handler.Out(0).Implements(errorType) {
			return fmt.Errorf("handler returns a single value, but it does not implement error")
		}
	}

	return nil
}
