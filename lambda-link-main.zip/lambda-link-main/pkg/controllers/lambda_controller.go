/*
Copyright 2022.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/awslabs/lambda-link/pkg/network"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/kubernetes"
	"sigs.k8s.io/controller-runtime/pkg/manager"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/awslabs/lambda-link/pkg/p2l"
	v12 "k8s.io/client-go/kubernetes/typed/coordination/v1"

	"go.uber.org/multierr"
	coordinationv1 "k8s.io/api/coordination/v1"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	corev1 "k8s.io/client-go/kubernetes/typed/core/v1"
	klog "k8s.io/klog/v2"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/predicate"
)

const lambdaNodeName = "lambda"
const lambdaLeaseNamespace = "kube-node-lease"

// LambdaReconciler reconciles the Lambda node and node lease objects
type LambdaReconciler struct {
	kubeClient           client.Client
	corev1Client         corev1.CoreV1Interface
	scheme               *runtime.Scheme
	pod2Lambda           p2l.P2L
	coordinationV1Client v12.CoordinationV1Interface
	nw                   *network.Network
	proxy                *p2l.Proxy

	creationTime time.Time

	mu           sync.Mutex
	podFunctions map[types.UID]string
	runningPods  map[types.UID]*p2l.ProxyInfo
	providerID   string
}

func NewLambdaReconciler(providerID string, mgr manager.Manager, clientSet *kubernetes.Clientset, pod2Lambda p2l.P2L, nw *network.Network, proxy *p2l.Proxy) *LambdaReconciler {
	return &LambdaReconciler{
		kubeClient:           mgr.GetClient(),
		corev1Client:         clientSet.CoreV1(),
		coordinationV1Client: clientSet.CoordinationV1(),
		scheme:               mgr.GetScheme(),
		pod2Lambda:           pod2Lambda,
		nw:                   nw,
		proxy:                proxy,
		podFunctions:         map[types.UID]string{},
		runningPods:          map[types.UID]*p2l.ProxyInfo{},
		providerID:           providerID,
	}
}

// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.12.2/pkg/reconcile
func (l *LambdaReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	// Create the Virtual Lambda Node
	_, err := l.createOrUpdateNode(ctx)
	if err != nil {
		klog.Errorf("unable to create or update lambda node: %v", err)
		return ctrl.Result{}, err
	}

	if _, err := l.corev1Client.Pods(req.Namespace).Get(ctx, req.Name, metav1.GetOptions{}); err != nil {
		if errors.IsNotFound(err) {
			return ctrl.Result{}, nil
		}
		klog.Errorf("unable to get pod %s/%s: %v", req.Namespace, req.Name, err)
		return ctrl.Result{}, fmt.Errorf("getting pod, %w", err)
	}

	// List pods that scheduled to the Lambda node
	podList, err := l.corev1Client.Pods(v1.NamespaceAll).List(ctx, metav1.ListOptions{})
	if err != nil {
		klog.Errorf("unable to fetch Pod: %v", err)
	}

	l.mu.Lock()
	defer l.mu.Unlock()
	var errs error

	// track all of the live pods and delete from this map if we still see them live, the pods remaining are those
	// that no longer exist
	podsToDelete := map[types.UID]struct{}{}
	for k := range l.runningPods {
		podsToDelete[k] = struct{}{}
	}

	for _, pod := range podList.Items {
		if pod.Spec.NodeName != lambdaNodeName {
			continue
		}
		p := pod.DeepCopy()
		delete(podsToDelete, p.UID)

		// pod was marked deleted but hasn't been deleted yet
		if p.ObjectMeta.DeletionTimestamp != nil {
			if time.Now().After(p.ObjectMeta.DeletionTimestamp.Add(time.Duration(*p.ObjectMeta.DeletionGracePeriodSeconds) * time.Second)) {
				if err := l.corev1Client.Pods(p.Namespace).Delete(ctx, p.Name, metav1.DeleteOptions{GracePeriodSeconds: aws.Int64(0)}); err != nil {
					klog.Errorf("unable to delete the pod %s/%s: %v", p.Namespace, p.Name, err)
					continue
				}
			}
		}

		// separate the function creation from the proxy setup so we don't continue to re-create functions
		// if proxy setup fails
		functionName, hasFunction := l.podFunctions[p.UID]
		if !hasFunction {
			lambdaName, err := l.pod2Lambda.Create(ctx, p)
			errs = multierr.Append(errs, err)
			if err == nil {
				functionName = lambdaName
				l.podFunctions[p.UID] = functionName
			}
		}
		// have we already marked it as running?
		proxyInfo, isRunning := l.runningPods[p.UID]
		if isRunning {
			if l.isJob(p) && p.Status.Phase != v1.PodFailed && p.Status.Phase != v1.PodSucceeded {
				fnStatus, err := l.pod2Lambda.GetLambdaStatus(ctx, p)
				if err != nil {
					klog.Errorf("unable to get pod %s/%s lambda func status: %v", p.Namespace, p.Name, err)
				}
				if fnStatus.State == p2l.StateCompleted {
					if fnStatus.Error != nil {
						p.Status.Phase = v1.PodFailed
					} else {
						p.Status.Phase = v1.PodSucceeded
					}
					if _, err := l.corev1Client.Pods(pod.Namespace).UpdateStatus(ctx, p, metav1.UpdateOptions{}); err != nil {
						klog.Errorf("unable to update phase (%s) for pod %s/%s: %v", p.Status.Phase, p.Namespace, p.Name, err)
						errs = multierr.Append(errs, err)
						continue
					}
				}
			}
		} else {
			// create our  proxy
			proxyInfo, err = l.proxy.SetupProxy(client.ObjectKeyFromObject(p), functionName)
			if err != nil || proxyInfo == nil {
				klog.Errorf("unable to setup proxy for pod %s/%s: %v", p.Namespace, p.Name, err)
				errs = multierr.Append(errs, err)
				continue
			}
			if l.isJob(p) {
				if err := l.pod2Lambda.Start(ctx, proxyInfo, functionName, p); err != nil {
					klog.Errorf("could not invoke pod %s/%s: %v", p.Namespace, p.Name, err)
					errs = multierr.Append(errs, err)
					continue
				}
			}
			if err := l.markPodAsRunning(ctx, p, proxyInfo); err != nil {
				klog.Errorf("could not mark pod %s/%s as running: %v", p.Namespace, p.Name, err)
				errs = multierr.Append(errs, err)
				continue
			}
			l.runningPods[p.UID] = proxyInfo
		}
	}

	l.cleanupRemovedPods(podsToDelete)
	return ctrl.Result{RequeueAfter: 30 * time.Second}, errs
}

func (l *LambdaReconciler) isJob(pod *v1.Pod) bool {
	for _, ownerRef := range pod.ObjectMeta.OwnerReferences {
		if ownerRef.Kind == "Job" {
			return true
		}
	}
	return false
}

func (l *LambdaReconciler) markPodAsRunning(ctx context.Context, pod *v1.Pod, proxy *p2l.ProxyInfo) error {
	conditions := []v1.PodCondition{
		{
			Type:          v1.PodInitialized,
			Status:        v1.ConditionTrue,
			LastProbeTime: metav1.Now(),
		},
		{
			Type:          v1.PodReady,
			Status:        v1.ConditionTrue,
			LastProbeTime: metav1.Now(),
		},
		{
			Type:          v1.ContainersReady,
			Status:        v1.ConditionTrue,
			LastProbeTime: metav1.Now(),
		},
	}
	pod.Status.Phase = v1.PodRunning
	pod.Status.PodIP = proxy.IP.String()
	// always set the lambda name in case it changes (e.g. old one was deleted)
	pod.Status.ContainerStatuses = []v1.ContainerStatus{
		{
			ContainerID: fmt.Sprintf("lambda://%s", proxy.LambdaName),
			Ready:       true,
			Started:     aws.Bool(true),
			State: v1.ContainerState{Running: &v1.ContainerStateRunning{
				StartedAt: metav1.Now(),
			}},
		},
	}
	if len(pod.Status.Conditions) == 1 {
		pod.Status.Conditions = append(pod.Status.Conditions, conditions...)
	}
	_, err := l.corev1Client.Pods(pod.Namespace).UpdateStatus(ctx, pod, metav1.UpdateOptions{})
	return err
}

func (l *LambdaReconciler) createOrUpdateLease(ctx context.Context) error {
	lease, err := l.coordinationV1Client.Leases(lambdaLeaseNamespace).Get(ctx, lambdaNodeName, metav1.GetOptions{})
	if err != nil && !errors.IsNotFound(err) {
		klog.Errorf("unable to fetch lambda node lease: %v", err)
		return err
	}
	if errors.IsNotFound(err) {
		_, err = l.coordinationV1Client.Leases(lambdaLeaseNamespace).Create(ctx, l.lambdaNodeLease(nil), metav1.CreateOptions{})
	} else {
		_, err = l.coordinationV1Client.Leases(lambdaLeaseNamespace).Update(ctx, l.lambdaNodeLease(lease), metav1.UpdateOptions{})
	}
	if err != nil {
		klog.Errorf("unable to create/update the lambda node lease: %v", err)
		return err
	}
	return nil
}

func (l *LambdaReconciler) createOrUpdateNode(ctx context.Context) (*v1.Node, error) {
	totalResourceRequests := v1.ResourceList{
		v1.ResourceCPU:    resource.MustParse("100000"),
		v1.ResourceMemory: resource.MustParse("100000G"),
		v1.ResourcePods:   resource.MustParse("100000"),
	}
	var node *v1.Node
	_, err := l.corev1Client.Nodes().Get(ctx, lambdaNodeName, metav1.GetOptions{})
	if err != nil && !errors.IsNotFound(err) {
		klog.Errorf("unable to fetch lambda node: %v", err)
		return nil, err
	}
	if errors.IsNotFound(err) {
		node, err = l.corev1Client.Nodes().Create(ctx, l.lambdaNode(totalResourceRequests), metav1.CreateOptions{})
	} else {
		node, err = l.corev1Client.Nodes().UpdateStatus(ctx, l.lambdaNode(totalResourceRequests), metav1.UpdateOptions{})
	}
	if err != nil {
		klog.Errorf("unable to create/update the lambda node: %v", err)
		return nil, err
	}
	err = l.createOrUpdateLease(ctx)
	return node, err
}

func (l *LambdaReconciler) lambdaNodeLease(existing *coordinationv1.Lease) *coordinationv1.Lease {
	lease := &coordinationv1.Lease{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: lambdaLeaseNamespace,
			Name:      lambdaNodeName,
		},
		Spec: coordinationv1.LeaseSpec{
			HolderIdentity:       aws.String(lambdaNodeName),
			LeaseDurationSeconds: aws.Int32(60),
			AcquireTime:          &metav1.MicroTime{Time: l.creationTime},
			RenewTime:            &metav1.MicroTime{Time: time.Now()},
		},
	}
	if existing != nil {
		lease.ResourceVersion = existing.ResourceVersion
	}
	return lease
}
func (l *LambdaReconciler) lambdaNode(capacity v1.ResourceList) *v1.Node {
	if l.creationTime.IsZero() {
		l.creationTime = time.Now()
	}
	return &v1.Node{
		ObjectMeta: metav1.ObjectMeta{
			Name: lambdaNodeName,
			Labels: map[string]string{
				"karpenter.sh/capacity-type":       "lambda",
				"node.kubernetes.io/instance-type": "Lambda",
				"beta.kubernetes.io/instance-type": "Lambda",
			},
		},
		Spec: v1.NodeSpec{
			Taints: []v1.Taint{
				{
					Key:    "karpenter.sh/capacity-type",
					Value:  "lambda",
					Effect: "NoSchedule",
				},
			},
			ProviderID: l.providerID,
		},
		Status: v1.NodeStatus{
			Addresses: []v1.NodeAddress{
				{
					Type:    v1.NodeInternalIP,
					Address: l.nw.NodeIP.String(),
				},
			},
			Conditions: []v1.NodeCondition{
				{
					Type:               v1.NodeReady,
					Status:             v1.ConditionTrue,
					LastHeartbeatTime:  metav1.Now(),
					Reason:             "Lambda Node Created",
					Message:            "Lambda Node Created",
					LastTransitionTime: metav1.NewTime(l.creationTime),
				},
				{
					Type:               v1.NodeDiskPressure,
					Status:             v1.ConditionFalse,
					LastHeartbeatTime:  metav1.Now(),
					LastTransitionTime: metav1.NewTime(l.creationTime),
				},
				{
					Type:               v1.NodeMemoryPressure,
					Status:             v1.ConditionFalse,
					LastHeartbeatTime:  metav1.Now(),
					LastTransitionTime: metav1.NewTime(l.creationTime),
				},
				{
					Type:               v1.NodeNetworkUnavailable,
					Status:             v1.ConditionFalse,
					LastHeartbeatTime:  metav1.Now(),
					LastTransitionTime: metav1.NewTime(l.creationTime),
				},
			},
			NodeInfo: v1.NodeSystemInfo{
				MachineID:               "Lambda",
				SystemUUID:              "",
				BootID:                  "",
				KernelVersion:           "5'ish",
				OSImage:                 "Amazon Linux",
				ContainerRuntimeVersion: "",
				KubeletVersion:          "EKS Compute Hackathon 2022",
				KubeProxyVersion:        "N/A",
				OperatingSystem:         "Amazon Linux",
				Architecture:            "amd64/arm64",
			},
			Capacity:    capacity,
			Allocatable: capacity,
		},
	}
}

// SetupWithManager sets up the controller with the Manager.
func (l *LambdaReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&v1.Pod{}).
		WithEventFilter(predicate.GenerationChangedPredicate{}).
		Complete(l)
}

// cleanupRemovedPods cleans up any pods that were previously, but not currently bound to the pod.  It assumes
func (l *LambdaReconciler) cleanupRemovedPods(toDelete map[types.UID]struct{}) {
	for uid := range toDelete {
		handler, ok := l.runningPods[uid]
		if !ok {
			continue
		}
		if err := handler.Shutdown(); err != nil {
			klog.Errorf("shutting down pod %s, %s", uid, err)
		}
		delete(l.runningPods, uid)
		delete(l.podFunctions, uid)
	}
}
