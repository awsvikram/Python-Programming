package p2l

import (
	"context"
	"fmt"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/kubernetes"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/lambda"
	"go.uber.org/multierr"
	"k8s.io/klog/v2"
)

func (p *Proxy) cleanupLambdas(client *kubernetes.Clientset) error {

	pods, err := client.CoreV1().Pods(v1.NamespaceAll).List(context.Background(), metav1.ListOptions{})
	if err != nil {
		return fmt.Errorf("listing pods, %w", err)
	}

	functionInUse := map[string]types.NamespacedName{}
	for i, p := range pods.Items {
		// FuncARNFromPod returns an empty string if there is no registered function, which is fine to put
		// in our functionInUse
		functionInUse[FuncARNFromPod(&pods.Items[i])] = types.NamespacedName{
			Namespace: p.Namespace,
			Name:      p.Name,
		}
	}

	var errs error
	err = multierr.Append(errs,
		p.lsvc.ListFunctionsPages(&lambda.ListFunctionsInput{}, func(output *lambda.ListFunctionsOutput, b bool) bool {
			for _, fn := range output.Functions {
				if user, inUse := functionInUse[aws.StringValue(fn.FunctionArn)]; inUse {
					klog.Infof("skipping cleanup of %s which is in use by %s", *fn.FunctionArn, user)
					continue
				}
				lfn, err := p.lsvc.GetFunction(&lambda.GetFunctionInput{
					FunctionName: fn.FunctionName,
				})
				if err != nil {
					errs = multierr.Append(errs, fmt.Errorf("getting function, %w", err))
					continue
				}
				if aws.StringValue(lfn.Tags["lambda-link"]) == "owned" {
					klog.Infof("removing old function %s", aws.StringValue(fn.FunctionArn))
					errs = multierr.Append(errs, p.deleteLambda(*fn.FunctionName))
				}
			}
			return true
		}))
	if err != nil {
		errs = multierr.Append(errs, fmt.Errorf("listing functions, %w", err))
	}
	return errs
}

func (p *Proxy) deleteLambda(functionName string) error {
	_, err := p.lsvc.DeleteFunction(&lambda.DeleteFunctionInput{
		FunctionName: &functionName,
	})
	if err != nil {
		return fmt.Errorf("deleting function %s, %w", functionName, err)
	}
	return nil
}
