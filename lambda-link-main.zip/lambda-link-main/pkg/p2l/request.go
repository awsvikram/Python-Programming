package p2l

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/aws/aws-lambda-go/events"
	"io"
	"k8s.io/apimachinery/pkg/util/uuid"
	"net/http"
	"time"
)

func HttpToAPIGateway(request *http.Request) (*events.APIGatewayProxyRequest, error) {
	defer request.Body.Close()
	body, err := io.ReadAll(request.Body)
	if err != nil {
		return nil, fmt.Errorf("reading request body, %w", err)
	}

	requestID := uuid.NewUUID()
	apiReq := &events.APIGatewayProxyRequest{
		Resource:                        "",
		Path:                            request.URL.Path,
		HTTPMethod:                      request.Method,
		Headers:                         singleValue(request.Header),
		MultiValueHeaders:               request.Header,
		QueryStringParameters:           singleValue(request.URL.Query()),
		MultiValueQueryStringParameters: request.URL.Query(),
		PathParameters:                  nil,
		RequestContext: events.APIGatewayProxyRequestContext{
			DomainName: request.Host,
			RequestID:  string(requestID),
			Protocol:   "HTTP/1.1",
			Identity: events.APIGatewayRequestIdentity{
				SourceIP:  request.RemoteAddr,
				UserAgent: request.UserAgent(),
			},
			ResourcePath:     request.URL.Path,
			Path:             request.URL.Path,
			HTTPMethod:       request.Method,
			RequestTime:      time.Now().Format("02/Jan/2006:15:04:05 -0700"),
			RequestTimeEpoch: time.Now().UnixMilli(),
		},
		Body:            string(body),
		IsBase64Encoded: false,
	}

	return apiReq, nil
}

func HttpToAPIGatewayRaw(request *http.Request) ([]byte, error) {
	apiReq, err := HttpToAPIGateway(request)
	if err != nil {
		return nil, fmt.Errorf("constructing API GW request, %w", err)
	}
	var buf bytes.Buffer
	if err := json.NewEncoder(&buf).Encode(apiReq); err != nil {
		return nil, fmt.Errorf("encoding, %s", err)
	}
	return buf.Bytes(), nil
}
func singleValue(header map[string][]string) map[string]string {
	ret := map[string]string{}
	for k, v := range header {
		if len(v) > 0 {
			ret[k] = v[0]
		}
	}
	return ret
}
