package p2l

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/ec2metadata"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
	"github.com/aws/aws-sdk-go/service/lambda"
	"github.com/oliveagle/jsonpath"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/klog/v2"
)

type P2L struct {
	lambdaAPI            *lambda.Lambda
	imds                 *ec2metadata.EC2Metadata
	ec2API               *ec2.EC2
	defaultExecutionRole string
	functionStatus       map[types.UID]*FunctionStatus
	instanceInfo         *InstanceInfo
}

type InstanceInfo struct {
	SecurityGroupIDs []*string
	SubnetIDs        []*string
}

var StatePending = "Pending"
var StateNotStarted = "NotStarted"
var StateRunning = "Running"
var StateCompleted = "Completed"

type FunctionStatus struct {
	State     string
	Error     error
	Response  string
	LogTail   string
	StartTime time.Time
	EndTime   time.Time
}

func New(sess *session.Session, defaultExecutionRole string) P2L {
	return P2L{
		lambdaAPI:            lambda.New(sess),
		imds:                 ec2metadata.New(sess),
		ec2API:               ec2.New(sess),
		defaultExecutionRole: defaultExecutionRole,
		functionStatus:       make(map[types.UID]*FunctionStatus),
	}
}

func (p P2L) Create(ctx context.Context, pod *v1.Pod) (string, error) {
	if funcArn := p.getValidFuncARNFromPod(pod); funcArn != "" {
		return funcArn, nil
	}
	podKey := fmt.Sprintf("%s/%s", pod.Namespace, pod.Name)
	if len(pod.Spec.InitContainers) != 0 {
		return "", fmt.Errorf("pod %s must have no init containers to create a lambda, found %d", podKey, len(pod.Spec.InitContainers))
	}
	if len(pod.Spec.Containers) != 1 {
		return "", fmt.Errorf("pod %s must have a single container to create a lambda, found %d", podKey, len(pod.Spec.Containers))
	}

	container := pod.Spec.Containers[0]
	if len(container.Ports) > 1 {
		return "", fmt.Errorf("pod %s must have either zero or one ports, found %d", podKey, len(container.Ports))
	}
	if len(container.Ports) == 1 && container.Ports[0].ContainerPort != 8888 {
		return "", fmt.Errorf("pod %s must have single listen on port 8888, found %d", podKey, container.Ports[0].ContainerPort)
	}

	// determine the amount of memory to request
	memoryRequest := int64(128)
	if memory, ok := container.Resources.Requests[v1.ResourceMemory]; ok {
		memoryBytes, _ := memory.AsInt64()
		memoryRequest = memoryBytes / 1024 / 1024
	}
	const mbsPerCPU = 10 * 1024 / 6
	if cpu, ok := container.Resources.Requests[v1.ResourceCPU]; ok {
		memoryByCPU := int64(mbsPerCPU * cpu.AsApproximateFloat64())
		if memoryByCPU > memoryRequest {
			memoryRequest = memoryByCPU
		}
	}

	instanceInfo, err := p.GetInstanceInfo(ctx)
	if err != nil {
		return "", err
	}
	fnc, err := p.lambdaAPI.CreateFunctionWithContext(ctx, &lambda.CreateFunctionInput{
		Architectures: aws.StringSlice([]string{"x86_64"}),
		Code: &lambda.FunctionCode{
			ImageUri: aws.String(container.Image),
		},
		Description:  aws.String(fmt.Sprintf("lambda-link lambda for pod %s", podKey)),
		Environment:  mapEnvironment(pod),
		FunctionName: p.randomFunctionName(),
		Handler:      nil,
		ImageConfig: &lambda.ImageConfig{
			// needed for ko-build images to work on lambda
			WorkingDirectory: aws.String("/tmp"),
		},
		Layers:      nil,
		MemorySize:  aws.Int64(memoryRequest),
		PackageType: aws.String("Image"),
		Publish:     aws.Bool(true),
		Role:        aws.String(p.defaultExecutionRole),
		Runtime:     nil,
		Tags: map[string]*string{
			"pod-uid":     aws.String(string(pod.UID)),
			"lambda-link": aws.String("owned"),
		},
		Timeout:       aws.Int64(900),
		TracingConfig: nil,
		VpcConfig: &lambda.VpcConfig{
			SecurityGroupIds: instanceInfo.SecurityGroupIDs,
			SubnetIds:        instanceInfo.SubnetIDs,
		},
	})
	if err != nil {
		return "", fmt.Errorf("unable to create lambda with %s, %w", p.defaultExecutionRole, err)
	}
	p.functionStatus[pod.UID] = &FunctionStatus{
		State: StateNotStarted,
	}
	klog.Infof("created lambda %s for pod %s", *fnc.FunctionArn, podKey)
	return *fnc.FunctionArn, nil
}

func FuncARNFromPod(pod *v1.Pod) string {
	if len(pod.Status.ContainerStatuses) == 0 {
		return ""
	}
	if splitStrs := strings.Split(pod.Status.ContainerStatuses[0].ContainerID, "://"); len(splitStrs) > 1 {
		return splitStrs[1]
	}
	return ""
}

func (p P2L) getValidFuncARNFromPod(pod *v1.Pod) string {
	funcName := FuncARNFromPod(pod)
	// ensure that the function exists
	fn, err := p.lambdaAPI.GetFunction(&lambda.GetFunctionInput{
		FunctionName: aws.String(funcName),
	})
	if err != nil {
		return ""
	}

	// if the function and code don't have the same image, we need a new function
	if fn.Code != nil && aws.StringValue(fn.Code.ImageUri) != pod.Spec.Containers[0].Image {
		klog.Info("function mismatch ", pod.Spec.Containers[0].Image, " and ", aws.StringValue(fn.Code.ImageUri))
		return ""
	}
	return funcName
}

func (p P2L) Start(ctx context.Context, proxyInfo *ProxyInfo, functionName string, pod *v1.Pod) error {
	if functionName == "" {
		functionName = p.getValidFuncARNFromPod(pod)
	}
	status, ok := p.functionStatus[pod.UID]
	if !ok {
		status = &FunctionStatus{}
		p.functionStatus[pod.UID] = status
	}
	if pod.Status.Phase == v1.PodFailed || pod.Status.Phase == v1.PodSucceeded {
		status.State = StateCompleted
		if pod.Status.Phase == v1.PodFailed {
			status.Error = fmt.Errorf("error occurred")
		}
		return nil
	}
	go func(status *FunctionStatus, pod v1.Pod) {
		status.State = StatePending
		if err := p.lambdaAPI.WaitUntilFunctionActiveV2WithContext(ctx, &lambda.GetFunctionInput{FunctionName: aws.String(functionName)}); err != nil {
			klog.Infof("lambda \"%s\" never entered active state, continuing: %v", functionName, err)
		}
		proxyInfo.WriteLog(fmt.Sprintf("[%s] invoking lambda %s\n", time.Now().Format(time.StampMilli), functionName))
		status.State = StateRunning
		status.StartTime = time.Now().UTC()
		out, err := p.lambdaAPI.InvokeWithContext(ctx, &lambda.InvokeInput{
			FunctionName: aws.String(functionName),
			LogType:      aws.String("Tail"),
		})
		status.EndTime = time.Now().UTC()
		status.State = StateCompleted
		if err != nil {
			status.Error = err
			return
		}
		if out.FunctionError != nil {
			status.Error = fmt.Errorf(*out.FunctionError)
		}
		status.Response = string(out.Payload)
		if out.LogResult != nil {
			decodedLog, err := base64.StdEncoding.DecodeString(*out.LogResult)
			if err != nil {
				klog.Errorf("can't decode base64 encoded log")
				return
			}
			proxyInfo.WriteLog(string(decodedLog))
			status.LogTail = *out.LogResult
		}
	}(status, *pod)
	return nil
}

func (p P2L) GetLambdaStatus(ctx context.Context, pod *v1.Pod) (FunctionStatus, error) {
	status, ok := p.functionStatus[pod.UID]
	if !ok {
		return FunctionStatus{}, fmt.Errorf("no status is recorded")
	}
	return *status, nil
}

func (p P2L) GetInstanceInfo(ctx context.Context) (*InstanceInfo, error) {
	if p.instanceInfo != nil {
		return p.instanceInfo, nil
	}
	identity, err := p.imds.GetInstanceIdentityDocumentWithContext(ctx)
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve the ec2 instance identity document from IMDS: %v", err)
	}

	instanceOut, err := p.ec2API.DescribeInstancesWithContext(ctx, &ec2.DescribeInstancesInput{
		InstanceIds: []*string{aws.String(identity.InstanceID)},
	})
	if err != nil {
		return nil, fmt.Errorf("unable to describe instance %s: %v", identity.InstanceID, err)
	}
	if len(instanceOut.Reservations) == 0 || len(instanceOut.Reservations[0].Instances) == 0 {
		return nil, fmt.Errorf("could not find instance-d %s: %v", identity.InstanceID, err)
	}
	instance := instanceOut.Reservations[0].Instances[0]
	var securityGroupIDs []*string
	for _, sg := range instance.SecurityGroups {
		securityGroupIDs = append(securityGroupIDs, sg.GroupId)
	}

	var subnetIDs []*string
	if err := p.ec2API.DescribeSubnetsPagesWithContext(ctx, &ec2.DescribeSubnetsInput{
		Filters: []*ec2.Filter{
			{
				Name:   aws.String("vpc-id"),
				Values: []*string{instance.VpcId},
			},
		},
	}, func(dso *ec2.DescribeSubnetsOutput, _ bool) bool {
		for _, sn := range dso.Subnets {
			subnetIDs = append(subnetIDs, sn.SubnetId)
		}
		return true
	}); err != nil {
		return nil, fmt.Errorf("unable to query ec2 for subnets in VPC %s: %v", *instance.VpcId, err)
	}

	p.instanceInfo = &InstanceInfo{
		SecurityGroupIDs: securityGroupIDs,
		SubnetIDs:        subnetIDs,
	}
	return p.instanceInfo, nil
}

func (p P2L) randomFunctionName() *string {
	var sb strings.Builder
	try := 0
	for {
		for i := 0; i < 40; i++ {
			v := rand.Intn(52)
			if v < 26 {
				sb.WriteByte('a' + byte(v))
			} else {
				sb.WriteByte('A' + byte(v-26))
			}
		}
		_, err := p.lambdaAPI.GetFunction(&lambda.GetFunctionInput{
			FunctionName: aws.String(sb.String()),
		})
		// if we get a not-found error, then we've identified a new function name that's not in use
		var notFound *lambda.ResourceNotFoundException
		if errors.As(err, &notFound) {
			break
		}
		sb.Reset()
		try++
		if try > 10 {
			klog.Fatalf("unable to determine unique function name, %w", err)
		}
	}
	return aws.String(sb.String())
}

func mapEnvironment(pod *v1.Pod) *lambda.Environment {
	env := pod.Spec.Containers[0].Env
	if len(env) == 0 {
		return nil
	}
	ret := &lambda.Environment{
		Variables: map[string]*string{},
	}
	for _, ev := range env {
		if ev.ValueFrom != nil && ev.ValueFrom.FieldRef != nil {
			podBytes, err := json.Marshal(pod)
			if err != nil {
				klog.Errorf("unable to marshal pod json to resolve fieldRef: %v", err)
				continue
			}
			var json_data interface{}
			if err := json.Unmarshal(podBytes, &json_data); err != nil {
				klog.Errorf("unable to unmarshal json to interface: %v", err)
				continue
			}
			val, err := jsonpath.JsonPathLookup(json_data, fmt.Sprintf("$.%s", ev.ValueFrom.FieldRef.FieldPath))
			if err != nil {
				klog.Errorf("unable to resolve environment fieldRef: %v", err)
				continue
			}
			ret.Variables[ev.Name] = aws.String(val.(string))

		} else {
			ret.Variables[ev.Name] = aws.String(ev.Value)
		}

	}
	return ret
}
