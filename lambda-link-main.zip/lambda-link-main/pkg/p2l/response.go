package p2l

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"github.com/aws/aws-lambda-go/events"
	"k8s.io/klog/v2"
	"net/http"
)

// DeliverResponse decodes an APIGatewayResponse and renders it as an HTTP response
func DeliverResponse(rsp []byte, w http.ResponseWriter) {
	var gwRsp events.APIGatewayProxyResponse
	if err := json.NewDecoder(bytes.NewReader(rsp)).Decode(&gwRsp); err != nil {
		klog.Errorf("decoding lambda response, %s", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	responseBody := []byte(gwRsp.Body)
	if gwRsp.IsBase64Encoded {
		decoded, err := base64.StdEncoding.DecodeString(gwRsp.Body)
		if err != nil {
			klog.Errorf("decoding base64 encoded body of lambda response, %s", err)
			http.Error(w, err.Error(), http.StatusInternalServerError)
		}
		responseBody = decoded
	}

	// per the docs if both the multi-value and single-value headers for a particular podKey are provided, the multi-value
	// headers are used
	for k, vals := range gwRsp.MultiValueHeaders {
		for _, v := range vals {
			w.Header().Add(k, v)
		}
	}
	for k, v := range gwRsp.Headers {
		if _, exists := w.Header()[k]; exists {
			continue
		}
		w.Header().Add(k, v)
	}
	w.WriteHeader(gwRsp.StatusCode)
	w.Write(responseBody)
}
