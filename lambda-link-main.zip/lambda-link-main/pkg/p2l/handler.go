package p2l

import (
	"encoding/base64"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/lambda"
	"k8s.io/klog/v2"
)

type handler struct {
	lambdaName string
	proxyInfo  *ProxyInfo
	once       sync.Once
	lsvc       *lambda.Lambda
}

func (h *handler) ServeHTTP(w http.ResponseWriter, request *http.Request) {
	h.once.Do(func() {
		if err := h.lsvc.WaitUntilFunctionActiveV2(&lambda.GetFunctionInput{FunctionName: aws.String(h.lambdaName)}); err != nil {
			klog.Infof("lambda \"%s\" never entered active state, trying anyway: %v", h.lambdaName, err)
		}
	})

	if !RequiresInvoke(request) {
		return
	}
	apiReq, err := HttpToAPIGatewayRaw(request)
	h.proxyInfo.WriteLog(fmt.Sprintf("[%s] invoking lambda %s\n", time.Now().Format(time.StampMilli), h.lambdaName))
	rsp, err := h.lsvc.Invoke(&lambda.InvokeInput{
		FunctionName: aws.String(h.lambdaName),
		LogType:      aws.String("Tail"),
		Payload:      apiReq,
	})
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	if rsp.LogResult != nil {
		decodedLog, err := base64.StdEncoding.DecodeString(string(*rsp.LogResult))
		if err != nil {
			klog.Errorf("can't decode base64 encoded log")
			return
		}
		h.proxyInfo.WriteLog(string(decodedLog))
	}

	DeliverResponse(rsp.Payload, w)
}

func RequiresInvoke(request *http.Request) bool {
	if request.Method == "HEAD" {
		return false
	}
	if strings.HasPrefix(request.UserAgent(), "ELB-HealthChecker") {
		return false
	}
	return true
}
