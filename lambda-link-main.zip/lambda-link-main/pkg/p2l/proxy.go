package p2l

import (
	"context"
	"fmt"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/lambda"
	"github.com/awslabs/lambda-link/pkg/network"
	"go.uber.org/multierr"
	"golang.org/x/sys/unix"
	"io"
	"k8s.io/client-go/kubernetes"
	"k8s.io/klog/v2"
	"net"
	"net/http"
	"os"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sync"
	"syscall"
)

const port = 8888

type Proxy struct {
	nw *network.Network

	mu             sync.Mutex
	ipReservations map[client.ObjectKey]net.IP // podKey -> IP
	usedIPs        map[string]client.ObjectKey // IP -> podKey
	runningProxies map[client.ObjectKey]*ProxyInfo
	sess           *session.Session
	lsvc           *lambda.Lambda
}

func NewProxy(nw *network.Network, sess *session.Session, clientSet *kubernetes.Clientset) (*Proxy, error) {
	p := &Proxy{
		nw:             nw,
		sess:           sess,
		ipReservations: map[client.ObjectKey]net.IP{},
		usedIPs:        map[string]client.ObjectKey{},
		runningProxies: map[client.ObjectKey]*ProxyInfo{},
		lsvc:           lambda.New(sess),
	}

	if err := p.cleanupLambdas(clientSet); err != nil {
		return nil, fmt.Errorf("cleaning up old lambda, %w", err)
	}
	return p, nil
}

type ProxyInfo struct {
	LambdaName string
	Listener   net.Listener
	IP         net.IP
	podKey     client.ObjectKey
	proxy      *Proxy

	mu      sync.Mutex
	LogFile *os.File
	writers map[notifyWriter]struct{}
}
type notifyWriter struct {
	WriterFlusher
	finished chan struct{}
}

func (p *ProxyInfo) Shutdown() error {
	klog.Infof("shutting down proxy for %s/%s", p.LambdaName, p.Listener.Addr())
	var errs error
	errs = multierr.Append(errs, p.Listener.Close())
	errs = multierr.Append(errs, p.proxy.FreeIP(p.IP))
	errs = multierr.Append(errs, p.proxy.deleteLambda(p.LambdaName))
	p.proxy.removeProxy(p.podKey)
	return errs
}

func (p *ProxyInfo) WriteLog(logLine string) {
	data := []byte(logLine)
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.LogFile != nil {
		p.LogFile.Write(data)
	}

	var writersToClose []notifyWriter
	for w := range p.writers {
		// try to write to everything registered, if we get an error
		// stop writing to it and notify the writer
		if _, err := w.Write(data); err != nil {
			writersToClose = append(writersToClose, w)
		}
		w.Flush()
	}
	// close any writers that we failed to write to
	for _, w := range writersToClose {
		delete(p.writers, w)
		close(w.finished)
	}
}

type WriterFlusher interface {
	io.Writer
	Flush()
}

func (p *ProxyInfo) AddWriter(w WriterFlusher) chan struct{} {
	nw := notifyWriter{
		WriterFlusher: w,
		finished:      make(chan struct{}),
	}
	p.mu.Lock()
	p.writers[nw] = struct{}{}
	p.mu.Unlock()
	return nw.finished
}

func (p *Proxy) SetupProxy(key client.ObjectKey, lambdaName string) (*ProxyInfo, error) {
	ip, err := p.ReserveIP(key)
	if err != nil {
		return nil, fmt.Errorf("reserving IP, %w", err)
	}

	if err := p.nw.AddLambdaIP(ip); err != nil {
		return nil, fmt.Errorf("adding IP to device, %w", err)
	}

	config := &net.ListenConfig{Control: reusePort}
	listener, err := config.Listen(context.Background(), "tcp", fmt.Sprintf("%s:%d", ip, port))
	if err != nil {
		return nil, fmt.Errorf("listening, %w", err)
	}
	logFile, err := os.CreateTemp("", "lambdalog-*")
	if err != nil {
		return nil, fmt.Errorf("creating lambda log file, %s", err)
	}
	pi := &ProxyInfo{
		IP:         ip,
		LambdaName: lambdaName,
		Listener:   listener,
		LogFile:    logFile,
		proxy:      p,
		writers:    map[notifyWriter]struct{}{},
	}
	go http.Serve(listener, &handler{
		proxyInfo:  pi,
		lambdaName: lambdaName,
		lsvc:       p.lsvc,
	})

	p.mu.Lock()
	defer p.mu.Unlock()
	p.runningProxies[key] = pi
	klog.Infof("listening on %s:%d for lambda %s", ip, port, lambdaName)
	return pi, nil
}

func (p *Proxy) ReserveIP(key client.ObjectKey) (net.IP, error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	// do we already have an IP reserved?
	if ip, isReserved := p.ipReservations[key]; isReserved {
		return ip, nil
	}

	var ipAssigned net.IP
	for _, ip := range p.nw.LambdaIPs() {
		_, inUse := p.usedIPs[ip.String()]
		if !inUse {
			ipAssigned = ip
			break
		}
	}
	if ipAssigned == nil {
		return nil, fmt.Errorf("IP ")
	}
	p.ipReservations[key] = ipAssigned
	p.usedIPs[ipAssigned.String()] = key
	return ipAssigned, nil
}

func (p *Proxy) FreeIP(ip net.IP) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	owner, isReserved := p.usedIPs[ip.String()]
	if !isReserved {
		// IP not in use
		return nil
	}

	// don't proceed if we can't remove the IP from the interface
	if err := p.nw.RemoveLambdaIP(ip); err != nil {
		return err
	}

	delete(p.usedIPs, ip.String())
	delete(p.ipReservations, owner)
	return nil
}

func (p *Proxy) ServeLogs(w http.ResponseWriter, namespace string, name string, container string, follow bool) {
	podKey := client.ObjectKey{Namespace: namespace, Name: name}

	p.mu.Lock()
	pi, ok := p.runningProxies[podKey]
	p.mu.Unlock()
	if !ok {
		klog.Errorf("Proxy info for %s not found", podKey)
		fmt.Fprintf(w, "Proxy info for %s not found\n", podKey)
		return
	}

	// non-follow, so just stream the entire file
	f, err := os.Open(pi.LogFile.Name())
	if err != nil {
		klog.Errorf("unable to open logfile for pod %s, %s", podKey, err)
		fmt.Fprintf(w, "unable to open logfile for pod %s, %s\n", podKey, err)
		return
	}
	defer f.Close()
	io.Copy(w, f)

	// follow mode
	if follow {
		wf := w.(WriterFlusher)
		// flush any old logs
		wf.Flush()
		finished := pi.AddWriter(wf)
		// wait until the writer is closed before we return
		<-finished
		return
	}
}

func (p *Proxy) removeProxy(key client.ObjectKey) {
	p.mu.Lock()
	defer p.mu.Unlock()
	delete(p.runningProxies, key)
}

func reusePort(network, address string, conn syscall.RawConn) error {
	return conn.Control(func(descriptor uintptr) {
		syscall.SetsockoptInt(int(descriptor), unix.SOL_SOCKET, unix.SO_REUSEPORT, 1)
		syscall.SetsockoptInt(int(descriptor), unix.SOL_SOCKET, unix.SO_REUSEADDR, 1)
	})
}
