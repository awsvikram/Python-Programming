package main

import (
	"flag"
	"fmt"
	"net/http"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

func main() {
	doRange := flag.Bool("range", false, "Perform a range of requests from 1 to count")
	count := flag.Int64("count", 20, "The the number of `requests` to send to the specified URL")
	flag.Parse()
	if flag.NArg() != 1 {
		flag.Usage()
		os.Exit(1)
	}

	if *doRange {
		for i := int64(0); i < *count; i++ {
			total := performQueries(i, flag.Arg(0))
			fmt.Printf("%d\t%f\n", i, total.Seconds())
		}
	} else {
		total := performQueries(*count, flag.Arg(0))
		fmt.Printf("%d requests took %f seconds", *count, total.Seconds())
	}
}

func performQueries(count int64, url string) time.Duration {
	var wg sync.WaitGroup
	var errors uint64
	start := time.Now()
	for i := int64(0); i < count; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			rsp, err := http.Get(url)
			if err != nil || rsp.StatusCode != 200 {
				atomic.AddUint64(&errors, 1)
			}
		}()
	}
	wg.Wait()
	total := time.Since(start)
	return total
}
