package main

import (
	"context"
	"flag"
	"fmt"
	"github.com/aws/aws-sdk-go/aws/ec2metadata"
	"github.com/awslabs/lambda-link/pkg/kubelet"
	"log"
	"os"

	"github.com/awslabs/lambda-link/pkg/dns"
	"github.com/awslabs/lambda-link/pkg/p2l"
	"sigs.k8s.io/controller-runtime/pkg/healthz"

	"github.com/awslabs/lambda-link/pkg/controllers"
	"github.com/awslabs/lambda-link/pkg/network"
	"github.com/awslabs/lambda-link/pkg/session"
	"k8s.io/client-go/kubernetes"
	_ "k8s.io/client-go/plugin/pkg/client/auth"
	"k8s.io/klog/v2"
	controllerruntime "sigs.k8s.io/controller-runtime"
	ctrl "sigs.k8s.io/controller-runtime"
)

func main() {
	defaultExecutionRole := flag.String("defaultExecutionRole", os.Getenv("DEFAULT_EXECUTION_ROLE"), "Lambda execution role to use for pods with no service account specified")
	flag.Parse()

	logger := klog.Background()
	ctrl.SetLogger(logger)

	ctx := context.Background()
	controllerRuntimeConfig := controllerruntime.GetConfigOrDie()
	clientSet := kubernetes.NewForConfigOrDie(controllerRuntimeConfig)

	mgr, err := ctrl.NewManager(ctrl.GetConfigOrDie(), ctrl.Options{
		//		scheme:                 scheme,
		MetricsBindAddress:     ":8080",
		Port:                   9443,
		HealthProbeBindAddress: ":8081",
		//		LeaderElection:         enableLeaderElection,
	})
	if err != nil {
		logger.Error(err, "unable to start manager")
		os.Exit(1)
	}

	mgr.AddHealthzCheck("default", healthz.Ping)
	mgr.AddReadyzCheck("default", healthz.Ping)

	sess := session.Create(ctx)
	klambda := p2l.New(sess, *defaultExecutionRole)
	nw, err := network.New(ctx, sess)
	if err != nil {
		klog.Fatalf("setting up network, %s", err)
	}
	proxy, err := p2l.NewProxy(nw, sess, clientSet)
	if err != nil {
		klog.Fatalf("setting up proxy, %s", err)
	}
	kube, err := kubelet.NewKubelet(nw, clientSet, sess, proxy)
	if err != nil {
		klog.Fatalf("setting up kubelet, %s", err)
	}
	_ = kube

	doc, _ := ec2metadata.New(sess).GetInstanceIdentityDocument()
	providerID := fmt.Sprintf("aws:///%s/%s", doc.AvailabilityZone, doc.InstanceID)
	if err = (controllers.NewLambdaReconciler(providerID, mgr, clientSet, klambda, nw, proxy)).SetupWithManager(mgr); err != nil {
		logger.Error(err, "unable to create controller", "Lambda")
		os.Exit(1)
	}

	if err = (dns.New(mgr, clientSet, sess)).SetupWithManager(mgr); err != nil {
		logger.Error(err, "unable to create controller", "DNS")
		os.Exit(1)
	}

	klog.Info("starting lambda-link controller")
	if err := mgr.Start(ctx); err != nil {
		log.Fatalf("starting manager: %s", err)
	}
}
