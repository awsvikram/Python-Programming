package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"os"
	"strconv"
	"time"

	"k8s.io/klog/v2"

	"github.com/aws/aws-lambda-go/events"
	"github.com/awslabs/lambda-link/pkg/lambda"
)

func main() {
	lambda.StartɁ(myHandler)
}

func myHandler(ctx context.Context, request events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {

	nthPrime := 25000
	if val, ok := request.QueryStringParameters["n"]; ok {
		n, err := strconv.ParseInt(val, 10, 64)
		if err != nil {
			klog.Errorf("error parsing n=%q, %s", val, err)
		} else {
			nthPrime = int(n)
		}
	}
	start := time.Now()
	type response struct {
		Description string
		Result      int64
		Duration    float64
		Callback    string
		NodeName    string
		PodName     string
	}
	var rsp response
	rsp.Description = fmt.Sprintf("Prime %d", nthPrime)
	rsp.Result = nthPrimeNaive(nthPrime)
	rsp.Duration = time.Since(start).Seconds()
	rsp.NodeName = os.Getenv("NODE_NAME")
	rsp.PodName = os.Getenv("POD_NAME")

	if val, ok := request.QueryStringParameters["callback"]; ok {
		var url string
		if val == "" {
			url = fmt.Sprintf("http://demo-lambda-deployment-service.default.svc.cluster.local?n=%d", nthPrime+1)
		}
		rsp.Callback = callbackToSvc(url)
	}

	hn, _ := os.Hostname()
	klog.Infof("Invoked on %s with query params %v", hn, request.QueryStringParameters)
	var body bytes.Buffer
	enc := json.NewEncoder(&body)
	if err := enc.Encode(rsp); err != nil {
		return events.APIGatewayProxyResponse{StatusCode: http.StatusInternalServerError}, fmt.Errorf("encoding response, %w", err)
	}
	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Headers: map[string]string{
			"content-type": "application/json",
		},
		Body: body.String(),
	}, nil
}

func callbackToSvc(url string) string {
	req := http.Client{Timeout: time.Second * 5}
	resp, err := req.Get(url)
	if err != nil {
		klog.Errorf("Unable to make HTTP GET request to %s: %v", url, err)
		return ""
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		klog.Errorf("Unable to ready response body from %s", url)
		return ""
	}
	klog.Infof("HTTP Request to \"%s\" -> Response: %v", url, string(body))
	return string(body)
}

func nthPrimeNaive(n int) int64 {
	v := big.NewInt(1)
	one := big.NewInt(1)
	for {
		if v.ProbablyPrime(100) {
			n--
			if n == 0 {
				break
			}
		}
		v.Add(v, one)
	}
	return v.Int64()
}
